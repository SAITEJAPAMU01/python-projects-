# HOTEL-MANGEMENT-GUI-AND-NORMAL-PROGRAM-PYTHON-
I have tried to computerize the hotel management system through my project.
The project is written in Python 3 that uses OOPS concept ie it is based on object and classes.

FOR THE GUI I HAVE USED TKINTER AND PAGE

THE NORMAL CODE IS NAMED AS MAIN.PY

TO RUN THE GUI JUST EXECUTE MAINLY.PY
